const carritoFrutas = [];

const agregarAlCarrito = (frutaid) => {
    if (frutaid > 0) {
        let productoEncontrado = productos.find((producto) => producto.id === parseInt(frutaid))
        if (productoEncontrado !== undefined) {
            carritoFrutas.push(productoEncontrado)
            console.table(carritoFrutas)
        }
    }
};
